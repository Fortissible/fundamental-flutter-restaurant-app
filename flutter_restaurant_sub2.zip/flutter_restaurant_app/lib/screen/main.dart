import 'package:flutter/material.dart';
import 'package:flutter_restaurant_app/bloc/detail/resto_detail_bloc.dart';
import 'package:flutter_restaurant_app/bloc/home/resto_list_bloc.dart';
import 'package:flutter_restaurant_app/domain/entities/restaurant_entity.dart';
import 'package:flutter_restaurant_app/screen/detail_restaurant.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_restaurant_app/utils/debouncer.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_restaurant_app/di/injection.dart' as di;

import '../bloc/home/resto_list_event.dart';
import '../bloc/home/resto_list_state.dart';

Future<void> main() async{
  WidgetsFlutterBinding.ensureInitialized();

  await di.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_)=>di.locator<RestaurantListBloc>()),
        BlocProvider(create: (_)=>di.locator<RestaurantDetailBloc>()),
      ],
      child: MaterialApp(
          title: 'Flutter Demo',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          initialRoute: '/',
          routes: {
            '/': (context) => const RestaurantHomePage(),
            '/detailScreen': (context) => DetailRestaurantPage(
                ModalRoute.of(context)?.settings.arguments as String
            )
          }
      ),
    );
  }
}

class RestaurantHomePage extends StatefulWidget {
  const RestaurantHomePage({super.key});

  @override
  State<RestaurantHomePage> createState() => _RestaurantHomePageState();
}

class _RestaurantHomePageState extends State<RestaurantHomePage> {
  final debouncer = Debouncer(milliseconds: 250);
  String query = "";

  @override
  void initState() {
    Future.microtask(
            () => context.read<RestaurantListBloc>().add(
            const RestaurantListSearchEvent()
        )
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Cari restoran untuk kamu...',
            ),
            cursorColor: Colors.black,
            onChanged: (restoQuery){
              query = restoQuery;
              debouncer.run(() {
                context.read<RestaurantListBloc>().add(
                    RestaurantListSearchQueryEvent(query: query)
                );
              });
            },
          ),
        ),
      ),
      body: Center(
        child: BlocBuilder<RestaurantListBloc,RestaurantListState>(
          builder: (context, state){
            if (state is RestaurantListLoading){
              return Center(
                child: Text(
                  "Please wait, loading...",
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 16
                  ),
                ),
              );
            } else if (state is RestaurantListLoaded){
              return ListView.builder(
                  itemCount: state.data.length,
                  itemBuilder: (context, index) {
                    return _buildRestaurantCardItem(context,state.data[index]);
                  }
              );
            } else if (state is RestaurantListNoData){
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Oh No...",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "We can't find the restaurant you're searching for...",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.normal,
                          fontSize: 16
                      ),
                    )
                  ],
                ),
              );
            } else if (state is RestaurantListError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Oh No...",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      state.msg,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.normal,
                          fontSize: 16
                      ),
                    )
                  ],
                ),
              );
            }
            else {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Oh No...",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "It seems, there is an error...",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.normal,
                          fontSize: 16
                      ),
                    )
                  ],
                ),
              );
            }
          }
        )
      ),
    );
  }

  Widget _buildRestaurantCardItem(BuildContext context, RestaurantEntity restaurant){
    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          ListTile(
            contentPadding: const EdgeInsets.all(16.0),
            leading: Container(
              width: 128,
              height: 150,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(8.0)),
                color: Colors.white,
              ),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(8.0)),
                child: Image.network(
                restaurant.pictureUrl,
                fit: BoxFit.cover,
                ),
              ),
            ),
            title: Text(
              restaurant.name
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(),
                Text(
                    "Location : ${restaurant.city}"
                ),
                Text(
                    "Rating : ${restaurant.rating}"
                ),
              ],
            )
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              TextButton(
                child: const Text('Check details'),
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    "/detailScreen",
                    arguments: restaurant.id
                  );
                },
              ),
              const SizedBox(width: 8),
              TextButton(
                child: const Text('Book restaurant'),
                onPressed: () {/* ... */},
              ),
              const SizedBox(width: 8),
            ],
          ),
        ],
      ),
    );
  }
}
