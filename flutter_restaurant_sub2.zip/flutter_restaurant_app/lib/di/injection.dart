import 'package:dio/dio.dart';
import 'package:flutter_restaurant_app/bloc/detail/resto_detail_bloc.dart';
import 'package:flutter_restaurant_app/data/remote_data_source/remote_data_source.dart';
import 'package:flutter_restaurant_app/domain/repository/repository.dart';
import 'package:get_it/get_it.dart';

import '../bloc/home/resto_list_bloc.dart';
import '../data/repository/repository_impl.dart';
final locator = GetIt.instance;
Future<void> init() async {

  locator.registerFactory<RestaurantListBloc>(
          () => RestaurantListBloc(repository: locator())
  );
  locator.registerFactory<RestaurantDetailBloc>(
          () => RestaurantDetailBloc(repository: locator())
  );

  locator.registerLazySingleton<Repository>(
          () => RepositoryImpl(remoteDataSource: locator())
  );

  locator.registerLazySingleton<RemoteDataSource>(
          () => RemoteDataSourceImpl(dio: locator())
  );

  final dio = Dio();
  // external
  locator.registerLazySingleton(
          () => dio
  );
}