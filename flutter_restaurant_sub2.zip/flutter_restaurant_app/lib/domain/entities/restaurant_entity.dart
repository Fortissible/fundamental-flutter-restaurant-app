import 'package:equatable/equatable.dart';

class RestaurantEntity extends Equatable{
  final String id;
  final String name;
  final String description;
  final String pictureUrl;
  final String city;
  final double rating;

  const RestaurantEntity({
    required this.id,
    required this.name,
    required this.description,
    required this.pictureUrl,
    required this.city,
    required this.rating,
  });

  @override
  List<Object?> get props => [id, name, description, pictureUrl, city, rating];
}