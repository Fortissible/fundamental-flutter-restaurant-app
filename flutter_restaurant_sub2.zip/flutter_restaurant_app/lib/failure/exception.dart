class ServerException implements Exception {
}