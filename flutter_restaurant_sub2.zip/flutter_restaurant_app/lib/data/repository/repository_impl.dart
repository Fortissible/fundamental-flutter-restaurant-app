import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_restaurant_app/data/model/restaurant_model.dart';
import 'package:flutter_restaurant_app/data/remote_data_source/remote_data_source.dart';
import 'package:flutter_restaurant_app/domain/entities/restaurant_detail_entity.dart';
import 'package:flutter_restaurant_app/domain/entities/restaurant_entity.dart';
import 'package:flutter_restaurant_app/domain/repository/repository.dart';
import 'package:flutter_restaurant_app/failure/failure.dart';

import '../../failure/exception.dart';
import '../response/restaurant_search_response.dart';

class RepositoryImpl implements Repository{
  final RemoteDataSource remoteDataSource;

  const RepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, List<RestaurantEntity>>> getListRestaurant() async {
    try {
      final restaurantListData = await remoteDataSource.getRestaurantList();
      final restaurantListEntity = restaurantListData.map(
              (restaurantEntity) => restaurantEntity.modelToEntity()
      ).toList();
      return Right(restaurantListEntity);
    } on SocketException catch (e){
      return Left(ConnectionFailure(e.message.toString()));
    }
  }

  @override
  Future<Either<Failure, RestaurantDetailEntity>> getRestaurantDetail(
      String id
      ) async {
    try {
      final restaurantDetailData = await remoteDataSource.getRestaurantDetail(id);
      final restaurantDetailEntity = restaurantDetailData.modelToEntity();
      return Right(restaurantDetailEntity);
    } on SocketException catch (e){
      return Left(ConnectionFailure(e.message.toString()));
    }
  }

  @override
  Future<Either<Failure, List<RestaurantEntity>>> searchRestaurant(String query)
    async{
      try {
        final restaurantListData = await remoteDataSource.searchRestaurant(query);
        final restaurantListEntity = restaurantListData.map(
                (restaurantEntity) => restaurantEntity.modelToEntity()
        ).toList();
        return Right(restaurantListEntity);
      } on SocketException catch (e){
        return Left(ConnectionFailure(e.message.toString()));
      }
  }

}