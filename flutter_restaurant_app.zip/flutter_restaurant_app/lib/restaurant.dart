import 'dart:convert';

class Menu {
  final String menu;

  Menu({
    required this.menu
  });

  factory Menu.fromJson(Map<String, dynamic> menu) => Menu(
    menu : menu['name']
  );
}

class Menus {
  final List<Menu> foods;
  final List<Menu> drinks;

  Menus({
    required this.foods,
    required this.drinks
  });

  factory Menus.fromJson(Map<String, dynamic> menus) {
    var listFoods = menus['foods'] as List;
    var listDrinks = menus['drinks'] as List;

    List<Menu> foods = listFoods.map((i) => Menu.fromJson(i)).toList();
    List<Menu> drinks = listDrinks.map((i) => Menu.fromJson(i)).toList();

    return Menus(
      foods: foods,
      drinks: drinks
    );
  }

}

class Restaurant {
  final String id;
  final String name;
  final String desc;
  final String image;
  final String city;
  final double rating;
  final Menus menus;

  Restaurant({
    required this.id,
    required this.name,
    required this.desc,
    required this.image,
    required this.city,
    required this.rating,
    required this.menus
  });

  factory Restaurant.fromJson(Map<String, dynamic> restaurant) {
    return Restaurant(
        id: restaurant['id'],
        name: restaurant['name'],
        desc: restaurant['description'],
        image: restaurant['pictureId'],
        city: restaurant['city'],
        rating: double.tryParse(restaurant['rating'].toString()) ?? 0,
        menus: Menus.fromJson(restaurant['menus'])
    );
  }
}

List<Restaurant> parseRestaurants (String? json) {
  if (json == null){
    return [];
  }
  final parsed = jsonDecode(json);
  final restaurants = parsed['restaurants'] as List;

  return restaurants.map((json) => Restaurant.fromJson(json)).toList();
}