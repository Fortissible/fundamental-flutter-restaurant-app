import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_restaurant_app/detailrestaurant.dart';
import 'package:flutter_restaurant_app/restaurant.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const RestaurantHomePage(),
        '/detailScreen': (context) => DetailRestaurantPage(
          ModalRoute.of(context)?.settings.arguments as Restaurant
        )
      }
    );
  }
}

class RestaurantHomePage extends StatelessWidget {
  const RestaurantHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Restaurants App Submission"
        ),
      ),
      body: Center(
        child: FutureBuilder<String>(
            future:
              DefaultAssetBundle.of(context).loadString('assets/local_restaurant.json'),
            builder: (context, snapshot) {
              final List<Restaurant> restaurants = parseRestaurants(snapshot.data);

              return ListView.builder(
                  itemCount: restaurants.length,
                  itemBuilder: (context, index) {
                    return _buildRestaurantCardItem(context,restaurants[index]);
                  }
              );
            }
        ),
      ),
    );
  }

  Widget _buildRestaurantCardItem(BuildContext context, Restaurant restaurant){
    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          ListTile(
            contentPadding: const EdgeInsets.all(16.0),
            leading: Container(
              width: 128,
              height: 150,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(8.0)),
                color: Colors.white,
              ),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(8.0)),
                child: Image.network(
                restaurant.image,
                fit: BoxFit.cover,
                ),
              ),
            ),
            title: Text(
              restaurant.name
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(),
                Text(
                    "Location : ${restaurant.city}"
                ),
                Text(
                    "Rating : ${restaurant.rating}"
                ),
              ],
            )
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              TextButton(
                child: const Text('Check details'),
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    "/detailScreen",
                    arguments: restaurant
                  );
                },
              ),
              const SizedBox(width: 8),
              TextButton(
                child: const Text('Book restaurant'),
                onPressed: () {/* ... */},
              ),
              const SizedBox(width: 8),
            ],
          ),
        ],
      ),
    );
  }
}
