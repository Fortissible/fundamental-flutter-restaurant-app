import 'package:flutter/material.dart';
import 'package:flutter_restaurant_app/restaurant.dart';

class DetailRestaurantPage extends StatelessWidget{
  final Restaurant restaurant;
  const DetailRestaurantPage(this.restaurant, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${restaurant.name} Restaurant"
        ),
      ),
      body: ListView(
        children: [
          _buildRestaurantCardItem(context,restaurant),
          Container(
            padding: const EdgeInsets.only(left: 16.0, right: 16.0),
            width: MediaQuery.of(context).size.width,
            child:const Text(
                "Drinks Menu",
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold
                ),
              ),
          ),
          _buildRestaurantCardMenuItem(context, restaurant.menus.drinks),
          Container(
            padding: const EdgeInsets.only(left: 16.0, right: 16.0),
            width: MediaQuery.of(context).size.width,
            child:const Text(
              "Foods Menu",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold
              ),
            ),
          ),
          _buildRestaurantCardMenuItem(context, restaurant.menus.foods),
        ],
      ),
    );
  }

  Widget _buildRestaurantCardItem(BuildContext context, Restaurant restaurant){
    return Card(
      margin: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(32.0),
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ClipRRect(
              borderRadius: const BorderRadius.all(Radius.circular(8.0)),
              child: Image.network(
                restaurant.image,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 8, height: 16,),
            Text(
              restaurant.name,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold
              ),
            ),
            const SizedBox(width: 8, height: 8,),
            Text(
              "Location   : ${restaurant.city}",
              style: const TextStyle(
                fontSize: 14,
              ),
            ),
            Text(
              "Rating       : ${restaurant.rating.toString()}",
              style: const TextStyle(
                fontSize: 14,
              ),
            ),
            const Divider(),
            Text(
              restaurant.desc,
              style: const TextStyle(
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRestaurantCardMenuItem(BuildContext context, List<Menu> menus){
    return SizedBox(
      height: 120,
      width: MediaQuery.of(context).size.width,
      child : ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: menus.length,
        itemBuilder: (context, idx) => Card(
            margin: const EdgeInsets.only(left: 16, right: 8, top:8, bottom: 8),
            child: UnconstrainedBox(
              child: Container(
                  padding: const EdgeInsets.all(16.0),
                  child: Row (
                    children: [
                      const Icon(
                          Icons.fastfood
                      ),
                      const SizedBox(width: 8, height: 8,),
                      Text(
                          menus[idx].menu
                      )
                    ],
                  )
              ),
            )
        )
      )
    );
  }
}
