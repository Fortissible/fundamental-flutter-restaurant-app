class ServerException implements Exception {
}

class DatabaseException implements Exception {
}